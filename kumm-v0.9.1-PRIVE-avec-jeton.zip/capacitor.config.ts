import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "fr.kumm.app",
  appName: "Kumm",
  webDir: "dist/web",
  server: { androidScheme: "https" },
  android: {
    // Autorise un serveur en http (test sur le réseau local). Mettez false quand le serveur est en https.
    allowMixedContent: true
  }
};

export default config;
