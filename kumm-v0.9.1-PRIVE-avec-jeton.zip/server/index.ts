// Serveur : sert l'app (dist/web) et relaie l'API CTS en gardant le token côté serveur.
import http from "node:http";
import type { ServerResponse } from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { ctsPaused, describeError, fetchCts, fetchRetry } from "./cts.js";
import { GEO_USER_AGENT, TRANSIT, geoUpstream } from "./geo.js";
import { OCCUPATION, VELHOP_INFO, parkingsRelais, poiResult, velhop } from "./poi.js";
import { TILE_ORIGIN, serveTile } from "./tiles.js";
import type { CtsResult } from "./cts.js";

const TOKEN = process.env.CTS_TOKEN;
if (!TOKEN) {
  console.error("CTS_TOKEN manquant : copiez .env.example en .env et renseignez-le.");
  process.exit(1);
}

const BASE = process.env.CTS_BASE ?? "https://api.cts-strasbourg.eu/v1/siri/2.0";
const PORT = Number(process.env.PORT ?? 3000);
const AUTH = "Basic " + Buffer.from(TOKEN + ":").toString("base64");

const here = path.dirname(fileURLToPath(import.meta.url));
const inDist = path.basename(path.dirname(here)) === "dist";
const WEB = inDist ? path.join(here, "..", "web") : path.join(here, "..", "dist", "web");

/** Endpoints autorisés et durée de cache en secondes */
const ALLOWED: Record<string, number> = {
  "stop-monitoring": 20,
  "stoppoints-discovery": 3600,
  "lines-discovery": 3600,
  "general-message": 60,
  "estimated-timetable": 30,
  "park-and-ride": 60,
  "veloparc": 3600,
  "retail-outlet": 3600
};

/** Les services « SIRI » sont sous /v1/siri/2.0 ; les autres (P+R, vélo, points de vente) sont cherchés d'abord sous /v1 */
const SIRI_ONLY = new Set(["stop-monitoring", "stoppoints-discovery", "lines-discovery", "general-message", "estimated-timetable"]);
const ROOT = process.env.CTS_ROOT ?? "https://api.cts-strasbourg.eu/v1";
/** Identifiant du demandeur exigé par le protocole SIRI (n'importe quel nom court) */
const REQUESTOR = process.env.CTS_REQUESTOR ?? "kumm";

/** Ajoute RequestorRef aux demandes SIRI s'il manque */
export function withRequestor(search: string): string {
  const q = new URLSearchParams(search);
  if (!q.has("RequestorRef")) q.set("RequestorRef", REQUESTOR);
  return "?" + q.toString();
}

interface CacheEntry { body: string; exp: number }
const cache = new Map<string, CacheEntry>();
const inflight = new Map<string, Promise<CtsResult>>();

const MIME: Record<string, string> = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".json": "application/json",
  ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".woff2": "font/woff2", ".webmanifest": "application/manifest+json"
};

function send(res: ServerResponse, status: number, type: string, body: string | Buffer, tag?: string): void {
  res.writeHead(status, tag ? { "Content-Type": type, "X-Cache": tag } : { "Content-Type": type });
  res.end(body);
}

/** Fin de validité d'une réponse : « ValidUntil » de la CTS si présent (entre 5 s et 1 h), sinon la durée par défaut */
export function expiry(body: string, ttl: number, now = Date.now()): number {
  const m = /"ValidUntil"\s*:\s*"([^"]+)"/.exec(body);
  const t = m ? Date.parse(m[1]) : NaN;
  if (Number.isNaN(t)) return now + ttl * 1000;
  return Math.min(Math.max(t, now + 5000), now + 3600_000);
}

/** Réponse avec cache, une seule requête sortante par clé, et dernière réponse connue en cas de panne */
async function cached(res: ServerResponse, key: string, ttl: number, fetcher: () => Promise<CtsResult>): Promise<void> {
  const hit = cache.get(key);
  if (hit && hit.exp > Date.now()) return send(res, 200, "application/json", hit.body, "HIT");

  // si 50 personnes demandent la même chose en même temps, un seul appel part vers le service
  let p = inflight.get(key);
  if (!p) {
    p = fetcher().finally(() => inflight.delete(key));
    inflight.set(key, p);
  }
  try {
    const r = await p;
    if (r.status === 200) {
      cache.set(key, { body: r.body, exp: expiry(r.body, ttl) });
      return send(res, 200, r.type, r.body, "MISS");
    }
    console.warn("Service externe", r.status, key.slice(0, 80), r.body.slice(0, 200));
    if (hit) return send(res, 200, "application/json", hit.body, "STALE");
    return send(res, r.status, r.type, r.body, "MISS");
  } catch (e) {
    const why = describeError(e);
    if (hit) return send(res, 200, "application/json", hit.body, "STALE");
    return send(res, 502, "text/plain", "Service injoignable : " + why);
  }
}

function api(res: ServerResponse, url: URL): Promise<void> | void {
  const name = url.pathname.slice("/api/".length);
  const ttl = ALLOWED[name];
  if (ttl === undefined) return send(res, 404, "text/plain", "Endpoint inconnu");
  const search = withRequestor(url.search);
  const fetcher = SIRI_ONLY.has(name)
    ? () => fetchCts(BASE, AUTH, name, search)
    : async () => {
        const r = await fetchCts(ROOT, AUTH, name, search);
        return r.status === 404 ? fetchCts(BASE, AUTH, name, search) : r;
      };
  return cached(res, name + search, ttl, fetcher);
}

function geo(res: ServerResponse, url: URL): Promise<void> | void {
  const g = geoUpstream(url);
  if (!g) return send(res, 400, "text/plain", "Paramètres invalides");
  return cached(res, g.url, g.ttl, () => fetchRetry(g.url, { "User-Agent": GEO_USER_AGENT, Accept: "application/json" }));
}

/* ---------- /diag : contrôle de la connexion, sans afficher le token ---------- */
interface Probe { status?: number; type?: string; error?: string; text?: string }
async function probe(url: string, headers: Record<string, string> = {}, wantText = false): Promise<Probe> {
  const ctl = new AbortController();
  const to = setTimeout(() => ctl.abort(), 6000);
  try {
    const r = await fetch(url, { headers, signal: ctl.signal });
    const type = r.headers.get("content-type") ?? "";
    return { status: r.status, type, text: wantText ? (await r.text()).slice(0, 4_000_000) : undefined };
  } catch (e) {
    return { error: describeError(e) };
  } finally {
    clearTimeout(to);
  }
}
const brief = (p: Probe): string => (p.error ? "ERREUR : " + p.error : String(p.status));

let lastDiag = 0;
async function diag(res: ServerResponse): Promise<void> {
  if (Date.now() - lastDiag < 10_000) return send(res, 429, "text/plain", "Patientez 10 secondes entre deux diagnostics");
  lastDiag = Date.now();
  const origin = new URL(ROOT).origin;
  const hdr = { Authorization: AUTH, Accept: "application/json" };

  const hosts = [`https://www.cts-strasbourg.eu`, `https://opendata.cts-strasbourg.eu`, origin];
  const reseau = Object.fromEntries(await Promise.all(hosts.map(async h => [h, brief(await probe(h))])));
  const siri = brief(await probe(`${BASE}/lines-discovery?RequestorRef=${REQUESTOR}`, hdr));

  const donnees: Record<string, string> = {};
  for (const name of ["park-and-ride", "veloparc", "retail-outlet"]) {
    for (const base of [ROOT, BASE]) donnees[`${base}/${name}`] = brief(await probe(`${base}/${name}?RequestorRef=${REQUESTOR}`, hdr));
  }

  // à la recherche d'une description de l'API (swagger) pour connaître les vrais chemins
  const docs: Record<string, string> = {};
  let chemins: string[] | undefined;
  for (const c of ["/swagger", "/swagger.json", "/swagger/v1/swagger.json", "/v1/swagger.json", "/openapi.json", "/v1/openapi.json", "/docs", "/v1/docs", "/api-docs", "/v1"]) {
    const r = await probe(origin + c, hdr, true);
    docs[origin + c] = brief(r);
    if (!chemins && r.text && r.status === 200) {
      try {
        const j = JSON.parse(r.text) as { paths?: Record<string, unknown> };
        if (j.paths) { chemins = Object.keys(j.paths).slice(0, 120); docs[origin + c] += " (description trouvée)"; }
      } catch { /* pas du JSON */ }
    }
  }

  // échantillons de données brutes, pour comprendre comment les lignes sont désignées
  const echantillons: Record<string, unknown> = {};
  try {
    const sp = await probe(`${BASE}/stoppoints-discovery?RequestorRef=${REQUESTOR}`, hdr, true);
    const st = (JSON.parse(sp.text ?? "{}") as { StopPointsDelivery?: { AnnotatedStopPointRef?: { Lines?: unknown[] }[] } }).StopPointsDelivery?.AnnotatedStopPointRef ?? [];
    const vues = new Set<string>();
    st.forEach(a => (a.Lines ?? []).forEach(l => vues.add(typeof l === "string" ? l : JSON.stringify(l))));
    echantillons["arrets"] = { total: st.length, avec_lignes: st.filter(a => (a.Lines ?? []).length > 0).length, lignes_vues_sur_les_arrets: [...vues].slice(0, 40), exemples: st.slice(0, 2) };
  } catch (e) { echantillons["arrets"] = "illisible : " + describeError(e); }
  try {
    const lp = await probe(`${BASE}/lines-discovery?RequestorRef=${REQUESTOR}`, hdr, true);
    const ln = (JSON.parse(lp.text ?? "{}") as { LinesDelivery?: { AnnotatedLineRef?: unknown[] } }).LinesDelivery?.AnnotatedLineRef ?? [];
    echantillons["lignes"] = { total: ln.length, exemples: ln.slice(0, 3) };
  } catch (e) { echantillons["lignes"] = "illisible : " + describeError(e); }

  // calculateur d'itinéraires en transports : Hoenheim → Gare Centrale
  let transitous: unknown;
  try {
    const tp = await probe(`${TRANSIT}?fromPlace=48.6190,7.7510&toPlace=48.5849,7.7352&numItineraries=3&language=fr`, { "User-Agent": GEO_USER_AGENT, Accept: "application/json" }, true);
    if (tp.error) transitous = "ERREUR : " + tp.error;
    else {
      const j = JSON.parse(tp.text ?? "{}") as { itineraries?: { duration: number; transfers: number; legs: { mode: string; routeShortName?: string }[] }[] };
      transitous = { statut: tp.status, nb_trajets: j.itineraries?.length ?? 0,
        premier: j.itineraries?.[0] ? { minutes: Math.round(j.itineraries[0].duration / 60), correspondances: j.itineraries[0].transfers, etapes: j.itineraries[0].legs.map(l => l.routeShortName ? `${l.mode} ${l.routeShortName}` : l.mode) } : null };
    }
  } catch (e) { transitous = "illisible : " + describeError(e); }

  // sources des catégories de la carte
  const sources: Record<string, string> = {};
  sources["tuiles de carte"] = brief(await probe(`${TILE_ORIGIN}/0/0/0.png`, { "User-Agent": GEO_USER_AGENT }));
  try { const v = await velhop(); sources["Vélhop (GBFS)"] = `${v.length} stations`; } catch (e) { sources["Vélhop (GBFS)"] = "ERREUR : " + describeError(e); }
  const occ = await probe(OCCUPATION, { "User-Agent": GEO_USER_AGENT, Accept: "application/json" }, true);
  sources["occupation des parkings (open data)"] = occ.error ? "ERREUR : " + occ.error : `HTTP ${occ.status}`;
  sources["adresse du flux Vélhop"] = VELHOP_INFO;

  const out = {
    version_node: process.version,
    token: { defini: Boolean(TOKEN) },   // jamais la moindre partie du jeton
    requestor_ref: REQUESTOR,
    pause_cts: ctsPaused(),
    reseau,
    siri_lines_discovery: siri,
    donnees_poi: donnees,
    transitous,
    sources_carte: sources,
    echantillons,
    documentation_api: docs,
    chemins_de_l_api: chemins ?? "aucune description trouvée"
  };
  send(res, 200, "application/json; charset=utf-8", JSON.stringify(out, null, 2));
}

function serveStatic(res: ServerResponse, url: URL): void {
  let p = path.normalize(decodeURIComponent(url.pathname));
  if (p === "/" || p === path.sep) p = "/index.html";
  const file = path.join(WEB, p);
  if (!file.startsWith(WEB)) return send(res, 403, "text/plain", "Interdit");
  fs.readFile(file, (err, data) => {
    if (err) return send(res, 404, "text/plain", "Introuvable (avez-vous lancé « npm run build » ?)");
    send(res, 200, MIME[path.extname(file)] ?? "application/octet-stream", data);
  });
}

/** Origines autorisées à appeler le serveur depuis un autre site (l'APK Android appelle depuis https://localhost) */
const ORIGINS = (process.env.CORS_ORIGINS ?? "https://localhost,http://localhost,capacitor://localhost,http://localhost:5173")
  .split(",").map(o => o.trim()).filter(Boolean);

/* ---------- limite de requêtes par adresse : protège votre jeton CTS si le serveur est public ---------- */
const LIMIT = Number(process.env.RATE_LIMIT_PER_MIN ?? 240);        // API, adresses, trajets, parkings… (0 = pas de limite)
const TILE_LIMIT = Number(process.env.TILE_LIMIT_PER_MIN ?? 1500);  // tuiles de carte
const TRUST_PROXY = process.env.TRUST_PROXY === "1";                // à activer derrière un hébergeur (adresse réelle dans X-Forwarded-For)
const ENABLE_DIAG = process.env.ENABLE_DIAG === "1";                // la page /diag n'existe que si vous l'activez
const hits = new Map<string, { n: number; reset: number }>();
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (v.reset < now) hits.delete(k); }, 60_000).unref();

function clientIp(req: http.IncomingMessage): string {
  if (TRUST_PROXY) {
    const f = req.headers["x-forwarded-for"];
    if (typeof f === "string" && f) return f.split(",")[0].trim();
  }
  return req.socket.remoteAddress ?? "?";
}

function withinLimit(req: http.IncomingMessage, bucket: "api" | "tiles", limit: number): boolean {
  if (limit <= 0) return true;
  const key = `${bucket}|${clientIp(req)}`, now = Date.now();
  let h = hits.get(key);
  if (!h || h.reset < now) { h = { n: 0, reset: now + 60_000 }; hits.set(key, h); }
  return ++h.n <= limit;
}

http.createServer((req, res) => {
  const url = new URL(req.url ?? "/", "http://localhost");
  const origin = req.headers.origin;
  if (origin && ORIGINS.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }
  if (req.method === "OPTIONS") { res.writeHead(204, { "Access-Control-Allow-Methods": "GET, OPTIONS", "Access-Control-Max-Age": "86400" }); return void res.end(); }
  if (req.method !== "GET") return send(res, 405, "text/plain", "Méthode non autorisée");
  const isTile = url.pathname.startsWith("/tiles/");
  const isService = url.pathname.startsWith("/api/") || url.pathname.startsWith("/geo/") || url.pathname.startsWith("/poi/");
  if ((isTile && !withinLimit(req, "tiles", TILE_LIMIT)) || (isService && !withinLimit(req, "api", LIMIT))) {
    res.writeHead(429, { "Content-Type": "text/plain", "Retry-After": "60" });
    return void res.end("Trop de requêtes : réessayez dans une minute");
  }
  if (url.pathname.startsWith("/api/")) void api(res, url);
  else if (url.pathname.startsWith("/geo/")) void geo(res, url);
  else if (url.pathname === "/poi/velhop") void cached(res, "poi:velhop", 60, async () => poiResult(await velhop()));
  else if (url.pathname === "/poi/pr") void cached(res, "poi:pr", 120, async () => poiResult(await parkingsRelais()));
  else if (url.pathname.startsWith("/tiles/")) void serveTile(res, url.pathname);
  else if (url.pathname === "/diag" && ENABLE_DIAG) void diag(res);
  else serveStatic(res, url);
}).listen(PORT, () => console.log(`Kumm : http://localhost:${PORT}`));
