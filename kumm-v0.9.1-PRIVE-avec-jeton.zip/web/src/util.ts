const ENT: Record<string, string> = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };

/** Échappe le texte venant de l'API avant de l'insérer dans du HTML */
export const esc = (s: unknown): string => String(s ?? "").replace(/[&<>"']/g, c => ENT[c]);
