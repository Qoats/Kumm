package fr.kumm.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
